/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog6112_prep_2018_q1;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author shail
 */
public class PROG6112_Prep_2018_Q1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // PROG6112 Revison: 2018 Exam Q1
        
        //var
        double[][]sales={
                            {900000,800000,500000},
                            {700000,500000,500000},
                            {800000,100000,50000},  //2D Array
                            {100000,200000,200000},
                            {300000,100000,50000}
                        };
        String[]artists={"Ed Sheeran","Pink","Bruno Mars",  //Single Array
                         "Foo Fighters","Taylor Swift"};
        
        Scanner kb = new Scanner(System.in);    //User input 
        DecimalFormat df = new DecimalFormat("###,###.##");
        
        System.err.println("Enter a position (between 1 and 5) to"+
                           " view the artist's CD, DVD and Blue Ray"+   //prompting user
                           " Sales for 2017");
        
        int userInput =0; //declaration and initialization of user input
        double totalSales=0;//declaration and initialization of sum of sales
        userInput=kb.nextInt();//captuirng user input 
               
        //output
        System.out.println(artists[userInput-1]+" was in position "+ 
                           userInput+" for 2017 sales");
         //subtracting 1 as array elements are from 0 to 4*
         System.out.println("*******************************************");
        
            for (int j = 0; j < sales[userInput-1].length; j++) {
                totalSales=totalSales+sales[userInput-1][j];
            }
        System.out.println("CD SALES: "+df.format(sales[userInput-1][0])+
                           "\nDVD SALES: "+df.format(sales[userInput-1][1])+
                           "\nBLUE RAY SALES: "+df.format(sales[userInput-1][2])+
                           "\nTOTAL: "+df.format(totalSales));
        System.out.println("*******************************************");
    }
    
}
